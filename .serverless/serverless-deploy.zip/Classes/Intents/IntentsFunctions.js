function getPreviousIntent() {

}

function getOutputContext() {

}
function getInputContext() {

}